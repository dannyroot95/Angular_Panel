import { Injectable, NgZone } from '@angular/core';
import { Ilogin } from 'src/app/interfaces/ilogin';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';
import { Iloggedinuser } from 'src/app/interfaces/iloggedinuser';
//import { auth } from 'firebase/app';
import { AngularFireAuth } from "@angular/fire/auth";
import { AngularFirestore, AngularFirestoreDocument } from '@angular/fire/firestore';
import { Router } from "@angular/router";
import { Observable } from 'rxjs';
import { AngularFireStorage } from '@angular/fire/storage';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  userData: any;
  constructor(
    private http: HttpClient,
    public afs: AngularFirestore,   // Inject Firestore service
    public afAuth: AngularFireAuth, // Inject Firebase auth service
    public router: Router,  
    public ngZone: NgZone, // NgZone service to remove outside scope warning
    private angularFireStorage: AngularFireStorage
  ) { 
      this.afAuth.authState.subscribe((user:any)=>{
        if(user){
          this.userData= user;
          localStorage.setItem('user',JSON.stringify(this.userData));
          console.log('data usuario0',this.userData);
          //JSON.parse(localStorage.getItem('user'));
        }

      })
    }
/*=============================================
=Login en Firebase Authentification =
=============================================*/
  login(data:Ilogin){
    //return "retornamos la data: "+JSON.stringify(data);
    //este servicio enviara al enpoint de firebase
    return this.http.post(environment.urlLogin,data).pipe(
      map((resp:any)=>{
        /*=============================================
        =capturamos el idToken y refreshToken =
        =============================================*/
        //console.log("resp",resp);
        //this.userData = resp;
        //localStorage.setItem('user',JSON.stringify(resp));
        //localStorage.setItem('user1',resp.email);
        localStorage.setItem('token',resp.idToken);
        localStorage.setItem('refreshToken',resp.refreshToken);
        console.log(resp.email);
        console.log(data)
        //nos va ayudar que el token se nos venza ya que el token de firebase tiene una hora de valide
        //si yo no lo vuelvo a actualizar me sacaria del sistema
        //el refreshToken es un token auxiliar que envía Fives para poder otra vez actualizar el token original.
        //console.log("resp",resp);
    }));
    // voy a mapear la respuesta que me retorne este httpost
    //pipe: una tuberia para poder ingresar a esa respuesta y hacer un mapeo


  }

  Signin(email:any,password:any){
    return this.afAuth.signInWithEmailAndPassword(email,password).then((result:any)=>{
      console.log("Result",result.user);
      this.SetUserData(result.user);

    }).catch((error:any)=>{

    })

  }

      /* Setting up user data when sign in with username/password, 
  sign up with username/password and sign in with social auth  
  provider in Firestore database using AngularFirestore + AngularFirestoreDocument service */
  SetUserData(user:any) {
    const userRef: AngularFirestoreDocument<any> = this.afs.doc(`users/${user.uid}`);
    //console.log("userReferenc",this.afs.doc(`users/${user.uid}`));
    const userData: Iloggedinuser = {
      email: user.email,
      address: user.address,
      dni: user.dni,
      mobile: user.mobile,
      firstName:user.firstName,
      gender:user.gender,
      lastName:user.lastName,
      type_product:user.type_product,
      name_store:user.name_store,
      type_user:user.type_user,
      ruc:user.ruc,
      delivery:user.delivery
      //photoURL: user.photoURL,
      //emailVerified: user.emailVerified
    }
    console.log('Referen',userData);
    return userRef.set(userData, {
      merge: true
    })
  }

  savePicProfile(croppedImage:any){
    const currentPictureId = Date.now();
    return this.angularFireStorage.ref(`User_Profile_Image${currentPictureId}.jpg`).
    putString(croppedImage,'data_url').then((res:any)=>{
      return new Promise((resolve,reject)=>{
        let picture=this.angularFireStorage.ref(`User_Profile_Image${currentPictureId}.jpg`).getDownloadURL();
        picture.subscribe((p:any)=>{
          return resolve(p)
        })
      })
    })

  }
  saveProduProfile(croppedImage:any){
    const currentPictureId = Date.now();
    return this.angularFireStorage.ref(`Product_Image${currentPictureId}.jpg`).
    putString(croppedImage,'data_url').then((res:any)=>{
      return new Promise((resolve,reject)=>{
        let picture=this.angularFireStorage.ref(`Product_Image${currentPictureId}.jpg`).getDownloadURL();
        picture.subscribe((p:any)=>{
          return resolve(p)
        })
      })
    })

  }


  getUserById(uid:any){
    return this.afs.doc('/users/'+uid);
  }
  getProduct(id:string):Observable<any>{
    return this.afs.collection('users').doc(id).snapshotChanges();
  }
  editUser(user:any) {
    return this.afs.doc('/users/' + user.uid).set(user);
  }
  setImage(image:any,uid:any){
    return this.afs.doc('/users/'+ uid +'/image').set(image);
  }
  actualizarUser(id:any,data:any): Promise<any>{
    //return this.afs.collection('users').doc('K5idkjuUN5QMXt571PAG9Ctp4fQ2').update(data);
    return this.afs.doc('/users/'+ id).set(data);
  }

}

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';


@Injectable({
  providedIn: 'root'
})
export class UsersService {

  constructor(private http:HttpClient) { }
  /*=============================================
  =Tomar la data de la coleccion usuarios en Firebase =
  =============================================*/
  getData(){
    //peduir que se retorne una peticion de tipo htttp y va a ser peticion de tipo get
    return this.http.get(`${environment.urlFirebase}Usuarios/Administrador.json`);
  }

}

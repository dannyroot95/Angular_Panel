import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
//utlizamos para comuni con el backen, para reutilizar codigo, para comunicarnos entre componentes
//vamos a utilizarlo para hacer peticion al backen
@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  constructor(private firestore: AngularFirestore) { }
  getProducts(): Observable<any>{
    return this.firestore.collection('products').snapshotChanges();
  }
  eliminarProducts(id:string):Promise<any>{
    return this.firestore.collection('products').doc(id).delete();
  }
  getProduct(id:string):Observable<any>{
    return this.firestore.collection('products').doc(id).snapshotChanges();
  }
  actualizarProducts(id:string,data:any): Promise<any>{
    return this.firestore.collection('products').doc(id).update(data);
  }
  getdatauser(uid:string):Observable<any>{
    return this.firestore.collection('users').doc(uid).snapshotChanges();
  }
}

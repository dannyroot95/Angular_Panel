export interface Iusers {
	//un conjunto de propiedades en donde le damos su respectivo signi
	apellidos:string;
	dni:string;
	email:string;
	nombres:string;
	telefono:string;
}

export interface Iproducts {
    description:string;
	name_store:string;
	price:string;
	stock_quantity:string;
	title:string;
	type_product:string;
}

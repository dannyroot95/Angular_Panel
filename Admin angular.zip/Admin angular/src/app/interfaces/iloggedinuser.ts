export interface Iloggedinuser {
	email:string;
	address:string;
	dni:string;
	mobile:string;
	firstName:string;
	gender:string;
	lastName:string;
	type_product:string;
	name_store:string;
	type_user:string;
	ruc:string;
	image?:string;
	delivery:string;
}

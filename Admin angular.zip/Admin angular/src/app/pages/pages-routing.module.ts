import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//componentes
//inportar los componentes que necesito que aparesca
import { MainPageComponent } from './main-page/main-page.component';
import { Error404Component } from './main-page/error404/error404.component';
import { CreateProductsComponent } from './main-page/products/create-products/create-products.component';
//import { HomeComponent } from './main-page/home/home.component';
//import { UsersComponent } from './main-page/users/users.component'
//import { CategoriesComponent } from './main-page/categories/categories.component'
//import { StoresComponent } from './main-page/stores/stores.component'
//import { ProductsComponent } from './main-page/products/products.component'
//import { OrdersComponent } from './main-page/orders/orders.component'
//import { SalesComponent } from './main-page/sales/sales.component'
import { AuthGuard } from 'src/app/guards/auth.guard';

//donde voy a configurar mis rutas de navegacion
const routes: Routes = [
//vamos a decir que la ruta principal es decir cuando no escriba nada en la url y todavia estemos
// en localhost:4200 el componente que necesito que me aparesca es el que viene en la clase MainPageComponent
//va a poder trabar con rutas en la url
{ path:'login', loadChildren:() => import('./login/login.module').then(m =>m.LoginModule)},
{ path:'', 
  component: MainPageComponent, canActivate: [ AuthGuard ],
  children: [ 
  //cargando el modulo home
  //esto se esta ejecutando en modo de promesa el punto then lo que hace es recibir 
  //un parametro m y el parametro m tiene que traer el modulo homemodule
  { path: '', loadChildren:() => import('./main-page/home/home.module').then(m =>m.HomeModule)},
  { path: 'users', loadChildren:()=> import('./main-page/users/users.module').then(m=>m.UsersModule)},
  { path: 'categories', loadChildren:()=> import('./main-page/categories/categories.module').then(m=>m.CategoriesModule)},
  { path: 'stores', loadChildren:()=>import('./main-page/stores/stores.module').then(m=>m.StoresModule)},
  { path: 'products', loadChildren:() => import('./main-page/products/products.module').then(m =>m.ProductsModule)},
  { path: 'orders', loadChildren:() => import('./main-page/orders/orders.module').then(m =>m.OrdersModule)},
  { path: 'sales', loadChildren:() => import('./main-page/stores/stores.module').then(m =>m.StoresModule) },
  { path: 'create-products' ,loadChildren:() => import('./main-page/products/create-products/create-products.module').then(m =>m.CreateProductsModule)},
  { path: 'editproducts/:id' ,loadChildren:() => import('./main-page/products/create-products/create-products.module').then(m =>m.CreateProductsModule)},
  { path: '**' , component: Error404Component}
  ]}
];

@NgModule({
  //estos son rutas hijas de la ruta principal
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PagesRoutingModule { }

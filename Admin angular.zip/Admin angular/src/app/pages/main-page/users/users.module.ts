import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
//componente
import { UsersComponent } from './users.component';
//rutas
import { UsersRoutingModule } from './users-routing.module';
//Angular Material
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';

import { MatSortModule } from '@angular/material/sort';

@NgModule({
  declarations: [
    UsersComponent,
  ],
  imports: [
    CommonModule,
    UsersRoutingModule,
    MatTableModule,MatPaginatorModule,MatSortModule
  ]
})
export class UsersModule { }

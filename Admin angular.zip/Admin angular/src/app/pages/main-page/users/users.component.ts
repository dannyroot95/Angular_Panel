import { Component, OnInit, ViewChild } from '@angular/core';
import { Iusers } from 'src/app/interfaces/iusers';
import { UsersService } from 'src/app/services/users.service';
import { MatPaginator } from '@angular/material/paginator';
//importar una clase que se llama:
import { MatTableDataSource } from '@angular/material/table';
import {animate, state, style, transition, trigger} from '@angular/animations';

import {MatSort} from '@angular/material/sort';

import { environment } from 'src/environments/environment';
import { functions } from 'src/app/helpers/functions';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed, void', style({height: '0px', minHeight: '0', display:'none'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
      transition('expanded <=> void', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ])
  ]
})
export class UsersComponent implements OnInit {
    /*=============================================================
  =Variable global que instancie la data que aparecera en la tabla =
  ==============================================================*/
  displayedColumns: string[] = ['position','foto','nombres', 'apellidos','actions'];


  /*=============================================================
  =Variable global que instancie la data que aparecera en la tabla =
  ==============================================================*/
  //va a tomar la informacion de la interfaz Iusers
  // ! para no me tenga en cuenta una comprobacion de clase estricta
  dataSource!: MatTableDataSource<Iusers>;


  /*=============================================
  =Variable global que tipifica la interface de usuario =
  =============================================*/
  //para que inice vacio esa interfaz
  users:Iusers[]=[];

  /*=========================================================================
  =Variable global que informa a la vista cuando hay una expansíon de la tabla=
  ===========================================================================*/

  expandedElement!: Iusers | null;

    /*=========================================================================
  =Variable global que captura la ruta de los archivos de imagen =
  ===========================================================================*/
  path= environment.urlFiles;

  /*=============================================
  =Variable global para definir tamaños de pantalla =
  =============================================*/
  screenSizeSM= false;

    /*=============================================
  =Variable global para saber cuando finaliza la carga de los datos =
  =============================================*/
  loadData = false;

  /*=============================================
  =Paginador =
  =============================================*/

  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort) sort!: MatSort;


  constructor(private usersService:UsersService) { }

  ngOnInit(): void {
    this.getData();
    /*=============================================
    =Definir tamaños de pantalla =
    =============================================*/
    if(functions.screenSize(0,767)){
      this.screenSizeSM=true;
    }
    else{
      this.screenSizeSM=false;
      this.displayedColumns.splice(2,0,'email');
      this.displayedColumns.splice(3,0,'dni');
      this.displayedColumns.splice(4,0,'telefono');
    }
    console.log("this.screenSizeSM",this.screenSizeSM);
    //console.log(this.users);
  }
  /*=============================================
  =Funcion para tener la data de usuarios =
  =============================================*/
  getData(){
    //verdadero cuando estoy solicitando los datos
    this.loadData = true;
    //vamos a disparar el servicio
    //retorna la toma de informacion que hace el .getData y con el subscribe reviso que respuesta me trae
    this.usersService.getData().subscribe((resp:any)=>{
       //console.log("resp",Object.keys(resp));
       //para traerme por separado cada uno de esos id uso el map
      let position=1;
      this.users= Object.keys(resp).map(a=>({
         //console.log("a",a);
          id:a,
          position:position++,
          foto:resp[a].foto,
          apellidos:resp[a].apellidos,
          dni:resp[a].dni,
          email:resp[a].email,
          nombres:resp[a].nombres,
          telefono:resp[a].telefono,
          //console.log("a", resp[a].nombres);
       }as Iusers));
       this.dataSource = new MatTableDataSource(this.users);
       console.log("this.dataSource",this.dataSource);
      //console.log("this.users",this.users);
      this.dataSource.paginator=this.paginator;
      this.dataSource.sort = this.sort;
      this.loadData = false;
    })

  }
  /*=============================================
  =Filtro de busqueda =
  =============================================*/
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}

import { Component, OnInit,ViewChild } from '@angular/core';
import { ProductsService } from 'src/app/services/products.service';

import { MatPaginator } from '@angular/material/paginator';
//importar una clase que se llama:
import { MatTableDataSource } from '@angular/material/table';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {MatSort} from '@angular/material/sort';
import { environment } from 'src/environments/environment';
import { functions } from 'src/app/helpers/functions';
//import { AngularFirestore } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  products: any[]=[];
  //items: Observable<any[]>;

  constructor(private _productsService: ProductsService, private toastr: ToastrService) { 
    //this.items= firestore.collection('products').valueChanges();
  }

  ngOnInit(): void {
   this.getProductos();
  }
  getProductos(){
    this._productsService.getProducts().subscribe(data=>{
      this.products=[];
      data.forEach((element:any) => {
        //console.log(element.payload.doc.id);
        //console.log(element.payload.doc.data());
        this.products.push({
          id: element.payload.doc.id,
          ...element.payload.doc.data()
        })
      });
      //console.log(data);
      console.log(this.products);
    });
  }

  eliminarProducts(id:string){
    this._productsService.eliminarProducts(id).then(()=>{
      console.log('Producto eliminado con exito');
      this.toastr.error('El Producto fue eliminado con exito','Registro Eliminado!',{
        positionClass:'toast-bottom-right'
      });
    }).catch(error=>{
      console.log(error);
    })
  }


}

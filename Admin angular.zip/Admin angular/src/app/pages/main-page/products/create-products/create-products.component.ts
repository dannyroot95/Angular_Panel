import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import { CreateproductsService } from './createproducts.service';
import { Router,ActivatedRoute } from '@angular/router';
import { AngularFirestore } from '@angular/fire/firestore';
import { ToastrService } from 'ngx-toastr';
import { ProductsService } from 'src/app/services/products.service';
import { AngularFireStorage } from '@angular/fire/storage';
import { finalize } from 'rxjs/operators';
import { Observable } from 'rxjs/internal/Observable';
import { AuthService } from 'src/app/services/auth.service';
import { LoginService } from 'src/app/services/login.service';

@Component({
  selector: 'app-create-products',
  templateUrl: './create-products.component.html',
  styleUrls: ['./create-products.component.css']
})
export class CreateProductsComponent implements OnInit {

  createProducts: FormGroup;
  submitted = false;
  loading=false;
  id:string|null;
  titulo = "Agregar Producto";
  uploadPercent: Observable<number | undefined>;
  urlImage: Observable<string | undefined>;
  date = new Date();
  name_store:any;
  type_product:any;
  user_name:any;
  id_user:any;
  delivery:any;
  imageedit:any;

  constructor(private fb: FormBuilder, private firestore: AngularFirestore,
    private toastr: ToastrService, private _productsService:ProductsService,
    private router:Router,private aRoute:ActivatedRoute, private storage:AngularFireStorage
    ,public authService:AuthService,public loginService:LoginService) { 
    this.createProducts = this.fb.group({
      description: ['', Validators.required],
      sku: ['',Validators.required],
      title: ['',Validators.required],
      price: ['',Validators.required],
      stock_quantity: ['',Validators.required]
    })
    this.id = this.aRoute.snapshot.paramMap.get('id');
    console.log(this.id);
    this.uploadPercent = new Observable;
    this.urlImage = new Observable;

  }
  public finalizado = false;
  public URLPublica = '';
  public porcentaje = 0;
  public nombreArchivo = '';
  datum:any;
  datumfinal:any;
  archivo:any;
  filepath:any;
  fileRef:any;
  tarea:any;


  ngOnInit(): void {
    this.esEditar();
    this.esObtenerUsuario();
  }
  agregarEditarProducto(){
    this.submitted=true;
    if(this.createProducts.invalid){
      return;
    }
    if(this.id==null){
      this.agregarProducto();
    }
    else{
      this.editarProducto(this.id);
    }
  }

  url: any= '';
  onUpload(event:any){
    if(event.target.files && event.target.files[0]){
      var reader = new FileReader();
      reader.onload = (event) => {
      this.url = (<FileReader>event.target).result;
      }
      reader.readAsDataURL(event.target.files[0]);
    }

    //para tener id unico para el nombre de la imagen que se vayamos a subir
    let id = Math.random().toString(36).substring(2);

    let fecha:string= ('0' + (this.date.getMonth() + 1)).slice(-2) + '/' + ('0' + this.date.getDate()).slice(-2) + '/' + this.date.getFullYear();
    let hora:string= ('0'+this.date.getHours()).slice(-2) + ':' + ('0'+this.date.getMinutes()).slice(-2) + ':' + ('0'+this.date.getSeconds()).slice(-2) +':'+ ('0'+ this.date.getMilliseconds()).slice(-2);
    let fechaHora:string= fecha+' '+hora;
    let fechaHorafinal= fechaHora.toString();
    console.log(fechaHorafinal);
    this.datum = Date.parse(fechaHorafinal);
    console.log(this.datum);
    this.datumfinal = this.datum/1000;
    console.log(this.datumfinal);

    this.archivo = event.target.files[0];
  }


  agregarProducto(){
    //ruta del fichero
    //let filePath = `Product_Image_${id}`;
    this.filepath = `Product_Image${this.datum}.jpg`;
    this.fileRef = this.storage.ref(this.filepath);
    //aca tenemos el fichero como tal
    //const file = event.target.files[0];
    //let referencia = this.storage.ref(filePath);
    this.tarea = this.storage.upload(this.filepath, this.archivo);

      this.tarea.snapshotChanges().pipe(finalize(()=>{
      this.fileRef.getDownloadURL().subscribe((UrlImage:any)=>{
        this.urlImage = UrlImage;
      })
    })
    ).subscribe();

    const producto: any ={
      description: this.createProducts.value.description,
      sku: this.createProducts.value.sku,
      title: this.createProducts.value.title,
      price: this.createProducts.value.price,
      stock_quantity: this.createProducts.value.stock_quantity,
      image: this.urlImage,
      name_store:this.name_store,
      type_product:this.type_product,
      user_name:this.user_name,
      user_id:this.id_user,
      delivery:this.delivery,
      provider_id:this.id_user
    }
    this.loading=true;
    console.log(producto);
    this.firestore.collection('products').add(producto).then(()=>{
      this.loading=false;
      this.toastr.success('El producto fue registrado con exito','producto registrado',{
        positionClass: 'toast-bottom-right'
      });
      //console.log('Empleado registrado con exito');
      this.router.navigate(['/products']);
    }).catch(error=>{
      console.log(error);
      this.loading=false;
    })
  }
  async editarProducto(id:string){
    const producto: any ={
      description: this.createProducts.value.description,
      sku: this.createProducts.value.sku,
      title: this.createProducts.value.title,
      price: this.createProducts.value.price,
      stock_quantity: this.createProducts.value.stock_quantity
    }
    this.loading=true;
    if(this.url){
      let picture = await this.loginService.saveProduProfile(this.url)
      producto.image = picture;
    }
    this._productsService.actualizarProducts(id,producto).then(()=>{
      this.loading=false;
      this.toastr.info('El Producto fue modificado con exito', 'Producto Modificado',{
        positionClass: 'toast-bottom-right'
      })
      this.router.navigate(['/products']);

    });

  }
  esEditar(){
    if(this.id !==null ){
      this.loading = true;
      this.titulo = "Editar Producto";
      this._productsService.getProduct(this.id).subscribe(data=>{
        this.loading = false;
        console.log(data.payload.data()['title']);
        this.imageedit=data.payload.data()['image']
        this.createProducts.setValue({
          description: data.payload.data()['description'],
          sku: data.payload.data()['sku'],
          title: data.payload.data()['title'],
          price: data.payload.data()['price'],
          stock_quantity: data.payload.data()['stock_quantity']
        })
      })
    }
    else{
      this.titulo = "Agregar Producto";
    }
  }

  esObtenerUsuario(){
    this.authService.getStatus().subscribe((status:any)=>{
      this._productsService.getdatauser(status.uid).subscribe(data=>{
        this.name_store=data.payload.data()['name_store'];
        this.type_product=data.payload.data()['type_product'];
        this.user_name=data.payload.data()['firstName'];
        this.id_user=data.payload.data()['id'];
        this.delivery=data.payload.data()['delivery'];


        this.createProducts.setValue({
          name_store: data.payload.data()['name_store'],
          type_product: data.payload.data()['type_product'],
          user_name: data.payload.data()['firstName']
        });
      });
    },(error)=> {
        console.log(error);
    });
  }

}

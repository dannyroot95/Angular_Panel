import { TestBed } from '@angular/core/testing';

import { CreateproductsService } from './createproducts.service';

describe('CreateproductsService', () => {
  let service: CreateproductsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CreateproductsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

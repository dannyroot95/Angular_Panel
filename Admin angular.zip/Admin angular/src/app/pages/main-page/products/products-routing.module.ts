import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//componentes
//inportar los componentes que necesito que aparesca
import { ProductsComponent } from './products.component';
//donde voy a configurar mis rutas de navegacion
const routes: Routes = [
//vamos a decir que la ruta principal es decir cuando no escriba nada en la url y todavia estemos
// en localhost:4200 el componente que necesito que me aparesca es el que viene en la clase MainPageComponent
//va a poder trabar con rutas en la url
{ path: '', component: ProductsComponent}
];

@NgModule({
  //estos son rutas hijas de la ruta principal
  //sigue siendo una ruta hija de las rutas principales
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProductsRoutingModule { }

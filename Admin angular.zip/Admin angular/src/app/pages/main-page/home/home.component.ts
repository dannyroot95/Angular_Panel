import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/services/auth.service';
import { FormBuilder,FormGroup, Validators } from '@angular/forms';
import { LoginService } from 'src/app/services/login.service';
import { Iloggedinuser } from 'src/app/interfaces/iloggedinuser';
import { Router,ActivatedRoute } from '@angular/router';
import { ImageCroppedEvent } from 'ngx-image-cropper';
import { AngularFireStorage } from '@angular/fire/storage';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  //editUsers: FormGroup;
  user!:Iloggedinuser;
  id:any;
  uid:any;
  datar:any
  imageChangedEvent: any = '';
  croppedImage: any = '';
  picture:any;

  constructor(public loginService: LoginService , public authService:AuthService,
    private fb: FormBuilder,private aRoute:ActivatedRoute,private angularFireStorage: AngularFireStorage,private toastr: ToastrService) { 
    /*this.editUsers = this.fb.group({
      firstName: ['', Validators.required],
      lastName: ['',Validators.required],
      email: ['',Validators.required],
      address: ['',Validators.required],
      dni: ['',Validators.required],
      ruc: ['',Validators.required],
      mobile: ['',Validators.required],
      gender: ['',Validators.required],
      type_product: ['',Validators.required],
      name_store: ['',Validators.required],
      type_user: ['',Validators.required]

    })*/
    this.authService.getStatus().subscribe((status:any)=>{
      this.uid=status.uid;
      this.loginService.getUserById(status.uid).valueChanges().subscribe((data:any)=>{
        this.user=data;
        console.log("informac",this.user);
      }, (error)=>{
          console.log(error);
      });

    }, (error)=> {
        console.log(error);
    });

    //this.id = this.aRoute.snapshot.paramMap.get('id');
  }

  ngOnInit(): void {
    //console.log(this.loginservice.userData);
    //this.esEditar();
    console.log("informac",this.user);
  }

  //ref me regresa una promesa por eso resolvemos la prome de pictures
  /*saveSettings(){
    if(this.croppedImage){
      const currentPictureId = Date.now();
      //convierto de base 64 que es una cadema de caracteres larga a un formato binario que es un archivo
      const pictures= this.angularFireStorage.ref(`User_Profile_Image${currentPictureId}.jpg`)
      .putString(this.croppedImage,'data_url');
      pictures.then((result)=>{
        //que me genere una url para ese formato binario
        //url del archivo binario
        this.picture=this.angularFireStorage.ref(`User_Profile_Image${currentPictureId}.jpg`).getDownloadURL();
        //obtenemos la url en texto ya no como string
        this.picture.subscribe((p:any)=>{
          this.loginService.setImage(p,this.user.uid).then(()=>{
            alert('Imagen subido correctamente');

          }).catch((error)=>{
            alert('Hubo un error al tratar de subir imagen');
            console.log(error);
          });
        });
      }).catch((error)=>{
        console.log(error);
      });
    }
    else{
      this.loginService.editUser(this.user).then(()=>{
        alert('Cambios guardados!');
      }).catch((error)=>{
        alert('Hubo un error');
        console.log(error);
      });
    }
  }*/
  esEditarfianal(){
    this.guardar(this.id);
  }

  async guardar(id:string){
    const datosfinal:any = {
      email:this.user.email,
      address:this.user.address,
      dni:this.user.dni,
      mobile:this.user.mobile,
      firstName:this.user.firstName,
      gender:this.user.gender,
      lastName:this.user.lastName,
      type_product:this.user.type_product,
      name_store:this.user.name_store,
      type_user:this.user.type_user,
      ruc:this.user.ruc,
      image:this.user.image || 'assets/img/user.jpg',
      delivery:this.user.delivery
    }
    if(this.croppedImage){
      let picture = await this.loginService.savePicProfile(this.croppedImage)
      datosfinal.image = picture;
    }
    this.loginService.actualizarUser(this.uid,datosfinal).then((data)=>{
      alert('Cambios guardados!');
      this.toastr.success('El usuario fue modificado con exito','usuario modificado',{
        positionClass: 'toast-bottom-right'
      });
    }).catch(error=>{
      console.log(error);
    })
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
  }
  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
  imageLoaded() {
    // show cropper
  }
  cropperReady() {
    // cropper ready
  }
  loadImageFailed() {
    // show message
  }

  /*esEditar(){
    this.loginService.getProduct(this.id).subscribe(data=>{
      //console.log(data.payload.data()['title']);
        this.editUsers.setValue({
          firstName: data.payload.data()['firstName'],
          lastName: data.payload.data()['lastName']
        })
    })
  }*/

}

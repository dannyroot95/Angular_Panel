import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms'
import { functions } from 'src/app/helpers/functions';
import { Ilogin } from 'src/app/interfaces/ilogin';
import { LoginService } from 'src/app/services/login.service';
import { alerts } from 'src/app/helpers/alerts';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  /*=============================================
  =           Grupo de Controles                =
  =============================================*/
  
  

  public f = this.form.group({
    email: ['',[Validators.required, Validators.email]],
    password: ['',[Validators.required]]
  })
  /*=============================================
  = Variable que valida el envio del formulario =
  =============================================*/
  formSubmitted= false;
  constructor(private form: FormBuilder, public loginservice:LoginService, private router:Router) { }

  ngOnInit(): void {
  }

  /*=============================================
  =           Function login              =
  =============================================*/
  login(){
    /*=============================================
    =Validando que el formulario haya sido enviado=
    =============================================*/
    this.formSubmitted= true;
    //otra forma tambien de validar el formulario y retorar que ya no haga nada si esta invalido
    //si este formulario en general es invalido que se cansele ya el codigo hay
    //validacon global de form.goup
    //console.log(this.f);

    /*=============================================
    = Validando que el formulario este correcto   =
    =============================================*/

    if(this.f.invalid){
      return;
    }

    /*=============================================
    =Capturamos la informacion del formulario en la interfaz=
    =============================================*/
    const data: Ilogin={
      email: this.f.controls.email.value,
      password: this.f.controls.password.value,
      returnSecureToken: true
    }

    /*=============================================
    =Ejecutamos el servicio del login=
    =============================================*/

    //console.log(this.loginservice.login(data));
    //como leer en mi componente el empoint
    //sino que simplemente lo que viene como respuesta  , viene como una promesa que debemos hacer lectura con un subscribe
    this.loginservice.login(data).subscribe(
        (resp)=>{
          /*=============================================
          =  Entramos al sistema  =
          =============================================*/
          //console.log("resp",resp);
          this.router.navigateByUrl("/");
          //this.loginservice.SetUserData(data);
          console.log("repuesr",data);
        },
        (err)=>{
          /*=============================================
           =Errores al intentar entrar al sistema=
          =============================================*/
          console.log("err",err);
          if(err.error.error.message ==  "EMAIL_NOT_FOUND"){
            alerts.basicAlert("Error","Correo Incorrecto","error");
          }else if(err.error.error.message ==  "INVALID_PASSWORD"){
            alerts.basicAlert("Error","Contraseña Incorrecta","error");
          }
          else{
            alerts.basicAlert("Error","Ocurrio un error","error");
          }
        }

      );
    /*console.log("Email : ", this.f.controls.email.value);
    console.log("Password : ", this.f.controls.password.value);*/
  }

  /*=============================================
  =Validamos formulario=
  =============================================*/

  invalidField(field:string){
    /*if(this.formSubmitted && this.f.controls[field].invalid){
      return true;
    }
    else{
      return false;
    }*/
    //pasar el nombre de campo , como segundo parametro el grupo de controles, como tercer parametro le
    //voy a enviar si ya se envio el formulario o no
    return functions.invalidField(field, this.f,this.formSubmitted);
  }

}

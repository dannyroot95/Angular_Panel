import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainPageComponent } from './main-page/main-page.component';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {SharedModule} from '../shared/shared.module';
//import { HomeComponent } from './main-page/home/home.component';

import { AppRoutingModule } from '../app-routing.module';
import { Error404Component } from './main-page/error404/error404.component';
//import { UsersComponent } from './main-page/users/users.component';
//import { CategoriesComponent } from './main-page/categories/categories.component';
//import { StoresComponent } from './main-page/stores/stores.component';
//import { ProductsComponent } from './main-page/products/products.component';
//import { OrdersComponent } from './main-page/orders/orders.component';
//import { SalesComponent } from './main-page/sales/sales.component';
@NgModule({
  declarations: [
    MainPageComponent,
    Error404Component,
    //HomeComponent,
    //UsersComponent,
    //CategoriesComponent,
    //StoresComponent,
    //ProductsComponent,
    //OrdersComponent,
    //SalesComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    AppRoutingModule,
    ToastrModule.forRoot(), // ToastrModule added
    BrowserAnimationsModule
  ]
})
export class PagesModule { }

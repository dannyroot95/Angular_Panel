import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

//las ruta con lo que va a trabajar las paginas
import {PagesRoutingModule} from './pages/pages-routing.module'

//componentes
//inportar los componentes que necesito que aparesca
import { MainPageComponent } from './pages/main-page/main-page.component';
//donde voy a configurar mis rutas de navegacion
const routes: Routes = [
{ path: '', redirectTo: '', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes),PagesRoutingModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }

//aca se utilizaran funciones reutilizables que en algun momente voy a tener que utilizar 
//en mi interfaz de programacion
import { FormGroup } from '@angular/forms'
/*=============================================
=funcion para validar campos del formulario =
=============================================*/
export class functions{
	static invalidField(field:string,f:FormGroup,formSubmitted:boolean):boolean{
		if(formSubmitted && f.controls[field].invalid){
	      return true;
	    }
	    else{
	      return false;
	    }
		
	}
	/*=============================================
	=funcion para determinar tamaños de pantalla =
	=============================================*/
	static screenSize(minWidth:number,maxWidth:number):boolean{
		//para averiguar en que tamaño de pantalla estoy
		if(window.matchMedia(`(min-width:${minWidth}px) and (max-width:${maxWidth}px)`).matches){
			return true;
		}
		else{
			return false;
		}
	}
}
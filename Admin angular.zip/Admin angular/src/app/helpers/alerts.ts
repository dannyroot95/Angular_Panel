import Swal , { SweetAlertIcon } from 'sweetalert2';
export class alerts{
/*=============================================
=funcion para alerta basica =
=============================================*/
	static basicAlert(title:string, text:string,icon:SweetAlertIcon){
		//Swal.fire(title,text,icon);
		Swal.fire({title,text,icon,background:"#ffffff"});
	}

}